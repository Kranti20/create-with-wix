export const SESSION_ID_STORAGE_KEY = 'fedops.logger.sessionId';
export const DEFAULT_APP_VERSION = '0.0.0';