import { create } from '@wix/fedops-logger';

export const fedopsLogger = create('marketing-template-viewer');
