export const infoPopUpDataHooks = {
  cardEditorUrl: 'card-editor-url',
  desktopOnlyNotice: 'desktop-only-notice',
  cardClose: 'card-close',
  cardTitle: 'card-title',
  cardGoodForTitle: 'card-good-for-title',
  cardGoodFor: 'card-good-for',
  cardDescription: 'card-description',
};
