export const mobileToolbarDataHooks = {
  logo: 'logo',
};
