export const mobileWixStudioToolbarDataHooks = {
  logo: 'logo',
  goToDesktop: 'go-to-desktop',
};
