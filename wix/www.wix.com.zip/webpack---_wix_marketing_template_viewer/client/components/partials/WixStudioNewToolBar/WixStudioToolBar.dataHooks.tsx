export const wixStudioToolBarDataHooks = {
  logo: 'logo',
  deviceSwitcher: 'device-switcher',
  editorLink: 'editor-link',
};
