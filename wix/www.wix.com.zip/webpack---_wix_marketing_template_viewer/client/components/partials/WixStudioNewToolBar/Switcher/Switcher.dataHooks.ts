export const switcherDataHooks = {
  desktopButton: 'switcher-button-desktop',
  tabletButton: 'switcher-button-tablet',
  mobileButton: 'switcher-button-mobile',
};
