export const switcherDataHooks = {
  switcherButtonDesktop: 'switcher-button-desktop',
  switcherButtonTablet: 'switcher-button-tablet',
  switcherButtonMobile: 'switcher-button-mobile',
};
