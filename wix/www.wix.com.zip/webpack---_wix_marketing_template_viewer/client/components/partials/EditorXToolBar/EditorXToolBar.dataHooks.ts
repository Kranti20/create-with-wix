export const editorXToolBarDataHooks = {
  logo: 'logo',
};
