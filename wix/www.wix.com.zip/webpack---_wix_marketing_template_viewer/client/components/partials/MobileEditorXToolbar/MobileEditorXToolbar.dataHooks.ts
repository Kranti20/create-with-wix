export const mobileEditorXToolbarDataHooks = {
  logo: 'logo',
  getStartedButton: 'get-started-button',
};
