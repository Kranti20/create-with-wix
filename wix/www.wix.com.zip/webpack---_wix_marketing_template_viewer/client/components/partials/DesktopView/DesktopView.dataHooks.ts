export const desktopViewDataHooks = {
  desktopIframe: 'desktop-iframe',
};
