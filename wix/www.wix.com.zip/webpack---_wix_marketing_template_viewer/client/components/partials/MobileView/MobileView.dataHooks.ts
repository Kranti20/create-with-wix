export const mobileViewDataHooks = {
  mobileIframe: 'mobile-iframe',
};
