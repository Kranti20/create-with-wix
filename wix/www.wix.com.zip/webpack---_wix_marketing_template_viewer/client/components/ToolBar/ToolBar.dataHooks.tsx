export const toolBarDataHooks = {
  logo: 'logo',
  desktopView: 'desktop-view',
  mobileView: 'mobile-view',
  toolBarTitle: 'tool-bar-title',
  infoView: 'info-view',
  editorLink: 'editor-link',
  backToTemplatesButton: 'back-to-templates',
};
