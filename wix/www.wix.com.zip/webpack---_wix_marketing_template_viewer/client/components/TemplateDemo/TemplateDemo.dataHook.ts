export const templateDemoDataHook = {
  desktopView: 'desktop-view',
  mobileView: 'mobile-view',
};
