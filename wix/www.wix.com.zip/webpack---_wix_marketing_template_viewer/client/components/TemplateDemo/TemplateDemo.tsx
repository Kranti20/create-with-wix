import React, { FC } from 'react';
import cs from 'classnames';
import { VIEW_MODE } from '../../utils/helpers';
import s from './templateDemo.scss';
import { templateDemoDataHook } from './TemplateDemo.dataHook';
import { DesktopView } from '../partials/DesktopView/DesktopView';
import { MobileView } from '../partials/MobileView/MobileView';
import { useTemplateContext } from '../../context/TemplateContext/TemplateContext';
import { useUIContext } from '../../context/UIContext/UIContext';

export const TemplateDemo: FC<{ dataHook?: string }> = ({ dataHook }) => {
  const { viewMode, isInfoShown } = useUIContext();
  const { template } = useTemplateContext();
  const { url, title } = template;

  return (
    <div data-hook={dataHook} className={cs(s.demoDisplay, { [s.disabled]: isInfoShown })}>
      {viewMode === VIEW_MODE.DESKTOP ? (
        <DesktopView url={url} title={title} dataHook={templateDemoDataHook.desktopView} />
      ) : (
        <MobileView url={url} title={title} dataHook={templateDemoDataHook.mobileView} />
      )}
    </div>
  );
};
