export const name = 'customUrlMapper' as const
export const CustomUrlMapperSymbol = Symbol('CustomUrlMapper')
