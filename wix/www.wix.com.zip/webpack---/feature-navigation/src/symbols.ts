export const NavigationSymbol = Symbol('Navigation')

export const name = 'navigation' as const
