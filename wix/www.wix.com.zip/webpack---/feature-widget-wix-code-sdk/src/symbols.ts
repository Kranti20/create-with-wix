export const name = 'widgetWixCodeSdk' as const
export const namespace = 'widget' as const
export const mainFrameEditorNamespace = 'mainFrameEditor' as const
