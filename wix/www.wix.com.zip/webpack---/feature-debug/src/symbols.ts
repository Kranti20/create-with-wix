export const name = 'debug' as const
export const TbDebugSymbol = Symbol('tbDebug')
export const TbDebugFeaturesSymbol = Symbol('TbDebugFeaturesSymbol')
export const DevToolsSymbol = Symbol('DevTools')
