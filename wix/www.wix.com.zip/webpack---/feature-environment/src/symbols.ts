export const name = 'environment' as const
