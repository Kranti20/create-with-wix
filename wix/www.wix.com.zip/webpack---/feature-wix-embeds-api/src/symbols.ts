export const name = 'wixEmbedsApi' as const
