import { instance } from '../bi-module/instance'

instance.sendBeat(12, 'Partially visible', { pageId: window.firstPageId })
