export const name = 'dynamicPages' as const
export const DynamicPagesResponseHandlerSymbol = Symbol('DynamicPagesResponseHandlerSymbol')
export const PermissionsHandlerSymbol = Symbol('PermissionsHandler')
export const PermissionsHandlerProviderSymbol = Symbol('PermissionsHandlerProvider')
