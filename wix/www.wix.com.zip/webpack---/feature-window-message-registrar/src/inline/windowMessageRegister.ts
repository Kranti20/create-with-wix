import { createRegistrar } from './createWindowMessageRegister'

createRegistrar(window)
