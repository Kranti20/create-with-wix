export const name = 'reporter' as const
export { ReporterSymbol } from '@wix/thunderbolt-symbols'
