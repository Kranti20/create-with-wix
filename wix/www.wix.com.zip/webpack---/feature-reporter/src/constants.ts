export const SERVER_EVENTS_APP_DEF_ID = 'cf06bdf3-5bab-4f20-b165-97fb723dac6a'
export const UTM_PARAMS_LOCAL_STORAGE_KEY = 'wix_utm_params'
export const BI_FIELD_CHAR_LIMIT = 4000
