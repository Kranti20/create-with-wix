export const name = 'testApi' as const
