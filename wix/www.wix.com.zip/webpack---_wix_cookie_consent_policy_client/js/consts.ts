export const BASE_DOMAINS = ['wix.com', 'editorx.com'];
export const COOKIE_NAME = 'consent-policy';
export const APP_DEF_ID = '22bef345-3c5b-4c18-b782-74d4085112ff';
export const GLOBAL_POLICY_CONTROL_SPEC =
  'specs.cookieConsent.PolicyByGlobalPrivacyControl';
