import { xhrPost } from './xhr-driver';
import {
  getCurrentPolicy,
  getConsentPolicyHeader,
  removeCookie,
} from './cookie-parser';
import {
  ConsentPolicyKey,
  ConsentPolicy,
  ConsentPolicyManagerConfig,
  ConsentPolicyManagerInterface,
  ConsentDetails,
  PolicySuccessCallback,
  PolicyErrorCallback,
  PolicyDetails,
} from '..';
import { EVENT_NAMES, publishEvent } from './events';
import { APP_DEF_ID } from './consts';
import { DEFAULT_POLICY } from '../default-policies';
import { getAPIBase } from './api-utils';
import { isWix } from './utils';

const trimTrailingSlash = (str: string): string =>
  str.endsWith('/') ? str.slice(0, -1) : str;

const dispatchPolicyChangedEvent = (policy: any) => {
  publishEvent(EVENT_NAMES.CONSENT_POLICY_CHANGED, [window as any, document], policy);
};

export class ConsentPolicyManager implements ConsentPolicyManagerInterface {
  private config: ConsentPolicyManagerConfig = {
    baseUrl: '',
  };
  //undocumented override of hostname for testing
  hostname = window.location.hostname;
  private initRan = false;
  /**
   * This function just fills in empty keys to allow setting a policy
   * It merges the current policy overriding it's keys
   * It may be called in different flows and SHOULD NOT be used as
   * a source of truth for the current policy, only how to construct a valid one
   * @param newPolicy
   * @returns
   */
  private readonly getValidPolicy = (newPolicy: any): ConsentPolicy => {
    const resultPolicy: any = {};
    const { policy } = this.getCurrentConsentPolicy();
    if (typeof newPolicy === 'object') {
      Object.keys(DEFAULT_POLICY).forEach((policyKey) => {
        if (typeof newPolicy[policyKey] === 'boolean') {
          resultPolicy[policyKey] = newPolicy[policyKey];
        }
      });
    }
    return { ...policy, ...resultPolicy };
  };

  private readonly shouldTriggerConsentPolicyChanged = (
    config: ConsentPolicyManagerConfig,
  ) => {
    // TODO: reconsider this code, it checks too many things.
    // All we really care about is if the current policy (ie CookiePolicy) is different from the one in the config sent to us
    return (
      config.consentPolicy &&
      this.initRan &&
      this.getCurrentConsentPolicy().defaultPolicy &&
      JSON.stringify(config.consentPolicy) !==
        JSON.stringify(this.getCurrentConsentPolicy().policy)
    );
  };

  init = (options: ConsentPolicyManagerConfig | string) => {
    const config =
      typeof options === 'string'
        ? { baseUrl: options }
        : {
            baseUrl: options.baseUrl,
            consentPolicy: options.consentPolicy,
          } || {};

    if (config.consentPolicy) {
      config.consentPolicy = this.getValidPolicy(config.consentPolicy);
    }

    let triggerConsentPolicyChanged = this.shouldTriggerConsentPolicyChanged(config);

    this.initRan = true;
    this.config = { ...this.config, ...config };
    this.config.baseUrl = trimTrailingSlash(this.config.baseUrl || '');

    //Getting the real state of the policy depdendant on the cookie as well
    const currentPolicy = this.getCurrentConsentPolicy();

    publishEvent(EVENT_NAMES.CONSENT_POLICIY_INITIALIZED, [window as any, document], currentPolicy);

    if (triggerConsentPolicyChanged) {
      dispatchPolicyChangedEvent(currentPolicy);
    }
  };

  setConsentPolicy = (
    policy: ConsentPolicy,
    successCallback?: PolicySuccessCallback,
    errorCallback?: PolicyErrorCallback,
  ) => {
    if (policy === void 0) {
      const err = 'setConsentPolicy: no policy sent as parameter';
      errorCallback && errorCallback(err);
      console.error(err);
    }
    const successCB = (data: string) => {
      try {
        const response: { consent: ConsentDetails } = JSON.parse(data);
        const updatedPolicyDetails: PolicyDetails = {
          defaultPolicy: false,
          policy: response.consent.policy,
        };
        const ts = response.consent.timestamp;
        if (ts) {
          updatedPolicyDetails.createdDate = new Date(ts);
        }
        dispatchPolicyChangedEvent(updatedPolicyDetails);
        successCallback && successCallback(updatedPolicyDetails);
      } catch (e) {
        errCB(e);
      }
    };

    const errCB = (details: any) => {
      errorCallback &&
        errorCallback(`Failed setting policy. details: ${details}`);
    };

    const policyString = JSON.stringify({
      policy: { ...this.getValidPolicy(policy), essential: true },
      location: location.href,
      ...(this.config.baseUrl ? { baseUrl: this.config.baseUrl } : {}),
    });

    const embedsAPI = (window as any).wixEmbedsAPI;
    const authorization =
      !isWix() &&
      embedsAPI &&
      embedsAPI.getAppToken &&
      embedsAPI.getAppToken(APP_DEF_ID);

    xhrPost(
      getAPIBase(this.config.baseUrl),
      successCB,
      errCB,
      policyString,
      authorization,
    );
  };

  getCurrentConsentPolicy = () =>
    getCurrentPolicy(this.hostname, this.config.consentPolicy);

  resetPolicy() {
    const cookieRemoved = removeCookie(this.config.baseUrl || '');
    if (cookieRemoved) {
      setTimeout(() => {
        //Magic number to allow cookie clearing
        dispatchPolicyChangedEvent(this.getCurrentConsentPolicy());
      }, 5);
    }
    return cookieRemoved;
  }

  publishPolicyUpdateRequestedEvent(categories: ConsentPolicyKey[] = []) {
    const categoriesArray = Array.isArray(categories) ? categories : [];

    const filteredCategories = categoriesArray.filter(
      (value, index, array) => array.indexOf(value) === index,
    );

    const event =
      filteredCategories.length === 0 ? {} : { categories: filteredCategories };
    publishEvent(
      EVENT_NAMES.CONSENT_POLICY_UPDATE_REQUESTED,
      [window as any, document],
      event,
    );
  }

  _getConsentPolicyHeader = () =>
    getConsentPolicyHeader(this.hostname, this.config.consentPolicy);
}
