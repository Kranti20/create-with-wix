import { ConsentPolicyManager } from './js/consent-policy-manager';
import { publishEvent, EVENT_NAMES } from './js/events';
import parseDomain from 'parse-domain';

export * from './js/consent-policy-manager';

if (typeof window !== 'undefined') {
  window.consentPolicyManager = new ConsentPolicyManager();
  publishEvent(
    EVENT_NAMES.CONSENT_POLICY_MANAGER_READY,
    [window as any, document],
    window.consentPolicyManager,
  );
}
